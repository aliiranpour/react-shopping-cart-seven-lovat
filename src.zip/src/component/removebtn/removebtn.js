import React from 'react'
import './removebtn.css'
const Removebtn = ({item}) => {
    return (
        <div className='rmvbtn'>
            <button className='removebtn'>Remove</button>
        </div>
  )
}

export default Removebtn