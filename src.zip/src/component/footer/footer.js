import './footer.css';

const Footer = () =>{
    return(
        <footer className="footer">
            <p>All right is reserved</p>
        </footer>
    )
}

export default Footer;